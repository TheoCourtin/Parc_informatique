1) Installer Wampserver 3.1.3 (64 bit) ou 3.0.6(32 bit)
   Lancer Wamp

2) Copier le dossier django_projects dans le dossier www du dossier wamp (c:\wamp\www\django_projects)

3) Installer Python 3.7.3
   Cocher la case add Python to PATH

4) T�l�chager pip 19.1.1 : https://pip.pypa.io/en/stable/installing/	
   T�l�charger get-pip.py et le placer dans le r�pertoire Python37-32 
   Ouvrir l'invite de commande , se placer dans ce r�pertoire, puis executer la commande 
	py get-pip.py 
	ou
	python get-pip.py
   
5) Ouvrir l'invite de commande, se placer dans le r�pertoire wamp\www\django_projects\parc_informatique 
   taper : 
	pip intall django 
	pip install django-composite-foreignkey
	pip install django-bootstrap4
	pip install django-bootstrap-datepicker-plus
	pip install pymysql

6) Ouvrir la console phpmyadmin (localhost/phpmyadmin/)
   cr�er une base nomm�e parc_informatique
   importer le fichier parc_informatique.sql qui est dans wamp\www\django_projects\parc_informatique\bdd
		
7) Aller dans Python37-32/Lib/site-packages/django/backends/mysql
Ouvrir le fichier base.py, mettre en commentaire la ligne :
#	if version < (1, 3, 7):
    
#		raise ImproperlyConfigured('mysqlclient 1.3.7 or newer is required; 
#		you have %s.' % Database.__version__)
Enregistrer

Puis aller dans operation.py, mettre en commentaire la ligne :
#	if query is not None :
#		query = query.decode(errors="replace")
#	return query
Enregistrer

8) Ouvrir l'invite de commande, se placer dans le r�pertoire wamp\www\django_projects\parc_informatique 
   taper : 
	py manage.py makemigrations
	py manage.py migrate
	py manage.py runserver

8) Sur le navigateur, taper l'adresse : 127.0.0.1:8000/site_web/
   Compte : admin, mot de passe : admin

