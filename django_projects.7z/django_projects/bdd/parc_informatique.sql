-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  mer. 08 mai 2019 à 13:38
-- Version du serveur :  5.7.21
-- Version de PHP :  7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `parc_informatique`
--

-- --------------------------------------------------------

--
-- Structure de la table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
CREATE TABLE IF NOT EXISTS `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
CREATE TABLE IF NOT EXISTS `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissions_group_id_b120cbf9` (`group_id`),
  KEY `auth_group_permissions_permission_id_84c5c92e` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
CREATE TABLE IF NOT EXISTS `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  KEY `auth_permission_content_type_id_2f476e4b` (`content_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add user', 4, 'add_user'),
(14, 'Can change user', 4, 'change_user'),
(15, 'Can delete user', 4, 'delete_user'),
(16, 'Can view user', 4, 'view_user'),
(17, 'Can add content type', 5, 'add_contenttype'),
(18, 'Can change content type', 5, 'change_contenttype'),
(19, 'Can delete content type', 5, 'delete_contenttype'),
(20, 'Can view content type', 5, 'view_contenttype'),
(21, 'Can add session', 6, 'add_session'),
(22, 'Can change session', 6, 'change_session'),
(23, 'Can delete session', 6, 'delete_session'),
(24, 'Can view session', 6, 'view_session');

-- --------------------------------------------------------

--
-- Structure de la table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
CREATE TABLE IF NOT EXISTS `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `auth_user`
--

INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`) VALUES
(1, 'pbkdf2_sha256$120000$opF5iFJz3YAW$8TmZQevY9ekFXv6L+8FBxWEELsptkNpch+0WWbHTerA=', '2019-05-06 13:10:54.610482', 1, 'admin', '', '', 'amakie@free.fr', 1, 1, '2019-04-10 14:54:08.633209'),
(2, 'pbkdf2_sha256$120000$BooVudSG42CO$l8rE4CMSf502usNhaJpGseGZeup4HzmlF+TmjILZqOM=', '2019-04-11 12:51:35.000000', 0, 'j.dupont', 'Jean', 'Dupont', '', 0, 1, '2019-04-10 15:15:25.000000');

-- --------------------------------------------------------

--
-- Structure de la table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
CREATE TABLE IF NOT EXISTS `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_user_id_6a12ed8b` (`user_id`),
  KEY `auth_user_groups_group_id_97559544` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
CREATE TABLE IF NOT EXISTS `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permissions_user_id_a95ead1b` (`user_id`),
  KEY `auth_user_user_permissions_permission_id_1fbb5f2c` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
CREATE TABLE IF NOT EXISTS `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `django_admin_log`
--

INSERT INTO `django_admin_log` (`id`, `action_time`, `object_id`, `object_repr`, `action_flag`, `change_message`, `content_type_id`, `user_id`) VALUES
(1, '2019-04-10 15:15:25.899358', '2', 'toto', 1, '[{\"added\": {}}]', 4, 1),
(2, '2019-04-12 14:46:30.956538', '2', 'j.dupont', 2, '[{\"changed\": {\"fields\": [\"username\", \"first_name\", \"last_name\"]}}]', 4, 1);

-- --------------------------------------------------------

--
-- Structure de la table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
CREATE TABLE IF NOT EXISTS `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(2, 'auth', 'permission'),
(3, 'auth', 'group'),
(4, 'auth', 'user'),
(5, 'contenttypes', 'contenttype'),
(6, 'sessions', 'session'),
(7, 'site_web', 'machine');

-- --------------------------------------------------------

--
-- Structure de la table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
CREATE TABLE IF NOT EXISTS `django_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2019-04-08 13:57:45.922930'),
(2, 'auth', '0001_initial', '2019-04-08 13:57:46.319520'),
(3, 'admin', '0001_initial', '2019-04-08 13:57:46.416171'),
(4, 'admin', '0002_logentry_remove_auto_add', '2019-04-08 13:57:46.429170'),
(5, 'admin', '0003_logentry_add_action_flag_choices', '2019-04-08 13:57:46.451183'),
(6, 'contenttypes', '0002_remove_content_type_name', '2019-04-08 13:57:46.505996'),
(7, 'auth', '0002_alter_permission_name_max_length', '2019-04-08 13:57:46.532388'),
(8, 'auth', '0003_alter_user_email_max_length', '2019-04-08 13:57:46.567906'),
(9, 'auth', '0004_alter_user_username_opts', '2019-04-08 13:57:46.581922'),
(10, 'auth', '0005_alter_user_last_login_null', '2019-04-08 13:57:46.609929'),
(11, 'auth', '0006_require_contenttypes_0002', '2019-04-08 13:57:46.614928'),
(12, 'auth', '0007_alter_validators_add_error_messages', '2019-04-08 13:57:46.627946'),
(13, 'auth', '0008_alter_user_username_max_length', '2019-04-08 13:57:46.659273'),
(14, 'auth', '0009_alter_user_last_name_max_length', '2019-04-08 13:57:46.686364'),
(15, 'sessions', '0001_initial', '2019-04-08 13:57:46.719145');

-- --------------------------------------------------------

--
-- Structure de la table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
CREATE TABLE IF NOT EXISTS `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('xeeblo60tulzyheop80zun8t7z4psydx', 'OWZkMGUyNGIzNjBkZTVjZmIyYzM3NTYyZTk3Mjc4ODI0OTk3NzVkMDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI0OGVlNWZiYzNlNzQ3YmZmZTFiOTJhNWMxZmI1ZTg3MmRkZjE5YzA5In0=', '2019-04-24 15:14:07.417366'),
('oj727xz4d5bsgf1cc7dmojzwajnukjdx', 'OWZkMGUyNGIzNjBkZTVjZmIyYzM3NTYyZTk3Mjc4ODI0OTk3NzVkMDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI0OGVlNWZiYzNlNzQ3YmZmZTFiOTJhNWMxZmI1ZTg3MmRkZjE5YzA5In0=', '2019-05-20 13:10:54.612493'),
('vk0gzg9jnqpf3g9w0hzrghvfx73gvwq8', 'OWZkMGUyNGIzNjBkZTVjZmIyYzM3NTYyZTk3Mjc4ODI0OTk3NzVkMDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI0OGVlNWZiYzNlNzQ3YmZmZTFiOTJhNWMxZmI1ZTg3MmRkZjE5YzA5In0=', '2019-05-02 09:20:23.037857');

-- --------------------------------------------------------

--
-- Structure de la table `etat_panne`
--

DROP TABLE IF EXISTS `etat_panne`;
CREATE TABLE IF NOT EXISTS `etat_panne` (
  `code` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(100) NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `etat_panne`
--

INSERT INTO `etat_panne` (`code`, `libelle`) VALUES
(1, 'En attente'),
(2, 'Prise en charge'),
(3, 'Résolue');

-- --------------------------------------------------------

--
-- Structure de la table `machine`
--

DROP TABLE IF EXISTS `machine`;
CREATE TABLE IF NOT EXISTS `machine` (
  `numero` int(11) NOT NULL,
  `codesalle` varchar(10) NOT NULL,
  `creation` datetime DEFAULT CURRENT_TIMESTAMP,
  `garbage` tinyint(1) NOT NULL,
  `idtypemachine` int(11) NOT NULL,
  PRIMARY KEY (`numero`,`codesalle`),
  KEY `codesalle` (`codesalle`),
  KEY `idtypemachine` (`idtypemachine`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `machine`
--

INSERT INTO `machine` (`numero`, `codesalle`, `creation`, `garbage`, `idtypemachine`) VALUES
(1, '1', '2018-03-19 10:00:00', 0, 1),
(3, '2', '2018-01-17 17:13:00', 0, 2),
(5, '2', '2018-02-01 12:02:00', 0, 1),
(6, '2', '2018-05-13 22:18:32', 0, 1),
(9, '1', '2018-04-14 22:23:40', 0, 1),
(11, '1', '2018-02-15 17:30:00', 0, 1),
(12, '1', '2018-04-18 13:56:36', 0, 1),
(13, '1', '2018-04-18 13:57:20', 0, 1),
(14, '1', '2018-04-18 14:16:30', 0, 1),
(15, '1', '2018-04-18 13:16:08', 0, 1);

-- --------------------------------------------------------

--
-- Structure de la table `panne`
--

DROP TABLE IF EXISTS `panne`;
CREATE TABLE IF NOT EXISTS `panne` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numeromachine` int(11) NOT NULL,
  `etat` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `id_reparateur` int(11) DEFAULT NULL,
  `datedetection` datetime DEFAULT NULL,
  `dateresolution` datetime DEFAULT NULL,
  `detecteur` varchar(250) CHARACTER SET latin1 NOT NULL,
  `description` text CHARACTER SET latin1 NOT NULL,
  `creation` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `garbage` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `numeromachine` (`numeromachine`),
  KEY `codesalle_2` (`numeromachine`),
  KEY `etat` (`etat`),
  KEY `type` (`type`),
  KEY `id_reparateur` (`id_reparateur`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `panne`
--

INSERT INTO `panne` (`id`, `numeromachine`, `etat`, `type`, `id_reparateur`, `datedetection`, `dateresolution`, `detecteur`, `description`, `creation`, `garbage`) VALUES
(17, 13, 1, 1, 4, '2018-04-19 00:00:00', NULL, 'eleve', 'ffds', '2018-04-18 14:16:18', 0),
(18, 14, 1, 1, 1, '2018-04-19 00:00:00', NULL, 'eleve', 'ffds', '2018-04-18 14:16:30', 0),
(22, 15, 1, 1, NULL, '2019-04-01 00:00:00', NULL, 'M. Truc', 'django test 1', '2019-04-19 09:27:08', 0),
(23, 9, 1, 2, NULL, '2019-04-22 16:48:13', NULL, 'M. Truc', 'Test', '2019-04-22 14:48:38', 0),
(24, 3, 1, 1, NULL, '2019-04-21 14:00:00', NULL, 'Mme Machin', 'Problème', '2019-04-22 16:01:53', 0),
(26, 15, 1, 2, NULL, '2019-04-30 16:29:00', NULL, 'M. Truc', 'bla', '2019-04-30 14:29:29', 0);

-- --------------------------------------------------------

--
-- Structure de la table `salle`
--

DROP TABLE IF EXISTS `salle`;
CREATE TABLE IF NOT EXISTS `salle` (
  `code` varchar(5) NOT NULL,
  `nom` varchar(100) NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `salle`
--

INSERT INTO `salle` (`code`, `nom`) VALUES
('1', 'Salle 117 BTS Sio'),
('2', 'Salle 119 BTS Sio');

-- --------------------------------------------------------

--
-- Structure de la table `type_machine`
--

DROP TABLE IF EXISTS `type_machine`;
CREATE TABLE IF NOT EXISTS `type_machine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `type_machine`
--

INSERT INTO `type_machine` (`id`, `libelle`) VALUES
(1, 'Fixe'),
(2, 'Portable');

-- --------------------------------------------------------

--
-- Structure de la table `type_panne`
--

DROP TABLE IF EXISTS `type_panne`;
CREATE TABLE IF NOT EXISTS `type_panne` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `type_panne`
--

INSERT INTO `type_panne` (`id`, `libelle`) VALUES
(1, 'Matérielle'),
(2, 'Logicielle');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
CREATE TABLE IF NOT EXISTS `utilisateur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(250) NOT NULL,
  `prenom` varchar(250) NOT NULL,
  `login` varchar(50) NOT NULL,
  `mdp` varchar(250) NOT NULL,
  `admin` char(1) DEFAULT NULL COMMENT 'Administrateur (O/N)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`id`, `nom`, `prenom`, `login`, `mdp`, `admin`) VALUES
(1, 'Dupont', 'Jean', 'j.dupont', 'test', 'N'),
(4, 'admin', 'admin', 'admin', 'admin', 'O');

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `machine`
--
ALTER TABLE `machine`
  ADD CONSTRAINT `machine_ibfk_1` FOREIGN KEY (`codesalle`) REFERENCES `salle` (`code`),
  ADD CONSTRAINT `machine_ibfk_2` FOREIGN KEY (`idtypemachine`) REFERENCES `type_machine` (`id`);

--
-- Contraintes pour la table `panne`
--
ALTER TABLE `panne`
  ADD CONSTRAINT `panne_ibfk_1` FOREIGN KEY (`numeromachine`) REFERENCES `machine` (`numero`),
  ADD CONSTRAINT `panne_ibfk_2` FOREIGN KEY (`etat`) REFERENCES `etat_panne` (`code`),
  ADD CONSTRAINT `panne_ibfk_3` FOREIGN KEY (`type`) REFERENCES `type_panne` (`id`),
  ADD CONSTRAINT `panne_ibfk_4` FOREIGN KEY (`id_reparateur`) REFERENCES `utilisateur` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
