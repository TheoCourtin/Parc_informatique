# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey has `on_delete` set to the desired behavior.
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models
from compositefk.fields import CompositeForeignKey
from django.utils import timezone
import datetime


class AuthGroup(models.Model):
    name = models.CharField(unique=True, max_length=80)

    class Meta:
        managed = False
        db_table = 'auth_group'


class AuthGroupPermissions(models.Model):
    group_id = models.IntegerField()
    permission_id = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'auth_group_permissions'
        unique_together = (('group_id', 'permission_id'),)


class AuthPermission(models.Model):
    name = models.CharField(max_length=255)
    content_type_id = models.IntegerField()
    codename = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'auth_permission'
        unique_together = (('content_type_id', 'codename'),)


class AuthUser(models.Model):
    password = models.CharField(max_length=128)
    last_login = models.DateTimeField(blank=True, null=True)
    is_superuser = models.IntegerField()
    username = models.CharField(unique=True, max_length=150)
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=150)
    email = models.CharField(max_length=254)
    is_staff = models.IntegerField()
    is_active = models.IntegerField()
    date_joined = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'auth_user'


class AuthUserGroups(models.Model):
    user_id = models.IntegerField()
    group_id = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'auth_user_groups'
        unique_together = (('user_id', 'group_id'),)


class AuthUserUserPermissions(models.Model):
    user_id = models.IntegerField()
    permission_id = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'auth_user_user_permissions'
        unique_together = (('user_id', 'permission_id'),)


class DjangoAdminLog(models.Model):
    action_time = models.DateTimeField()
    object_id = models.TextField(blank=True, null=True)
    object_repr = models.CharField(max_length=200)
    action_flag = models.PositiveSmallIntegerField()
    change_message = models.TextField()
    content_type_id = models.IntegerField(blank=True, null=True)
    user_id = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'django_admin_log'


class DjangoContentType(models.Model):
    app_label = models.CharField(max_length=100)
    model = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'django_content_type'
        unique_together = (('app_label', 'model'),)


class DjangoMigrations(models.Model):
    app = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    applied = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_migrations'


class DjangoSession(models.Model):
    session_key = models.CharField(primary_key=True, max_length=40)
    session_data = models.TextField()
    expire_date = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_session'


class Machine(models.Model):
    numero = models.IntegerField(primary_key=True)
    codesalle = models.ForeignKey('Salle', models.DO_NOTHING, db_column='codesalle')
    creation = models.DateTimeField(blank=True, null=True)
    garbage = models.IntegerField()
    idtypemachine = models.ForeignKey('Type_Machine', models.DO_NOTHING, db_column='idtypemachine')

    def nom_salle_machine(self):
        return self.codesalle.nom

    def nature_machine(self):
        return self.idtypemachine.libelle

    def numero_machine(self):
        return self.numero

    def __unicode__(self):
       return self.nom_salle_machine() + ' / ' + str(self.numero)

    def __str__(self):
        return " {0} / {1}".format(self.nom_salle_machine(), self.numero)
        #return str(self.numero)

    class Meta:
        managed = False
        db_table = 'machine'
        unique_together = (('numero', 'codesalle'),)


class Panne(models.Model):
    id = models.IntegerField(primary_key=True, editable=False)
    #codesalle = models.ForeignKey('Salle', models.DO_NOTHING, db_column='codesalle', related_name='%(class)s_codesalle', verbose_name="Code de la salle", editable=False)
    numeromachine = models.ForeignKey('Machine', models.DO_NOTHING, db_column='numeromachine', verbose_name="Numéro de machine")
    # codesalle = models.CharField(max_length=5, verbose_name="Code de la salle")

    #numeromachine = models.IntegerField(verbose_name="Numéro de machine")
    etat = models.ForeignKey('Etat_Panne', models.DO_NOTHING, db_column='etat', default=1, verbose_name="Etat de la panne")
    type = models.ForeignKey('Type_Panne', models.DO_NOTHING, db_column='type', verbose_name="Type de panne")
    id_reparateur = models.ForeignKey('Utilisateur', models.DO_NOTHING, db_column='id_reparateur', blank=True, null=True, editable=False, default=None)
    datedetection = models.DateTimeField(blank=True, null=True, verbose_name="Date de détection", default=datetime.datetime.today)
    dateresolution = models.DateTimeField(blank=True, null=True, editable=False, verbose_name='Date de résolution')
    detecteur = models.CharField(max_length=250,verbose_name="Nom du détecteur")
    description = models.TextField()
    creation = models.DateTimeField(editable=False, auto_now_add=True, blank=True, verbose_name="Date de création")
    garbage = models.IntegerField(editable=False, default=0)

    #machinefk = CompositeForeignKey(Machine, on_delete=models.CASCADE, to_fields={"codesalle" : "codesalle",
    #"numero" : "numeromachine"})

    def etat_panne(self):
        return self.etat.libelle

    def type_panne(self):
        return self.type.libelle

    def nom_salle(self):
        return self.numeromachine.nom_salle_machine()

    def nom_machine(self):
        return self.numeromachine.__unicode__()

    def get_absolute_url(self):
     return reverse('panne-details', args=[str(self.id)])

    def nature_machine(self):
        return self.numeromachine.nature_machine()

    def nom_intervenant(self):
        if self.id_reparateur is None:
            return ' '
        else:
            return self.id_reparateur.nom + ' ' + self.id_reparateur.prenom

    class Meta:
        managed = False
        db_table = 'panne'


class Salle(models.Model):
    code = models.CharField(primary_key=True, max_length=5)
    nom = models.CharField(max_length=100)

    def __unicode__(self):
       return self.nom

    def __str__(self):
        return self.nom

    class Meta:
        managed = False
        db_table = 'salle'


class Type_Machine(models.Model):
    id = models.IntegerField(primary_key=True)
    libelle = models.CharField(max_length=100)

    def nature_machine(self):
        return self.libelle

    def __str__(self):
        return self.libelle

    def __unicode__(self):
       return self.libelle

    class Meta:
        managed = False
        db_table = 'type_machine'

class Etat_Panne(models.Model):
    code = models.IntegerField(primary_key=True)
    libelle = models.CharField(max_length=100)

    def etat_panne(self):
        return self.libelle

    def __str__(self):
        return self.libelle

    def __unicode__(self):
       return self.libelle

    class Meta:
        managed = False
        db_table = 'etat_panne'

class Type_Panne(models.Model):
    id = models.IntegerField(primary_key=True)
    libelle = models.CharField(max_length=150)

    def nature_panne(self):
        return self.libelle

    def __str__(self):
        return self.libelle

    def __unicode__(self):
         return self.libelle

    class Meta:
        managed = False
        db_table = 'type_panne'

class Utilisateur(models.Model):
    id = models.IntegerField(primary_key=True)
    nom = models.CharField(max_length=250)
    prenom = models.CharField(max_length=250)
    login = models.CharField(max_length=50)
    mdp = models.CharField(max_length=250)
    admin = models.CharField(max_length=1, blank=True, null=True)

    def information_intervenant(self):
        return self.nom + ' ' + self.prenom

    class Meta:
        managed = False
        db_table = 'utilisateur'
