from django.shortcuts import render, render_to_response
from django.http import HttpResponse
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import AuthenticationForm
from django.views.generic.detail import DetailView
from .forms import PanneForm
from django.views.generic.list import ListView
from site_web.models import Panne, Type_Machine, Type_Panne, Utilisateur, Salle, Machine, Etat_Panne
from django.utils import timezone
from django.views.generic.edit import CreateView, DeleteView, UpdateView
from django.urls import reverse_lazy, reverse
from django.shortcuts import get_object_or_404
from bootstrap_datepicker_plus import DatePickerInput, DateTimePickerInput

# Import de la classe HttpResponsedu module django.http
# Create your views here.

class PanneListView(ListView):
    template_name = "panne-list.html"
    model = Panne
    paginate_by = 100  # if pagination is desired

    def get_context_data(self,**kwargs):
        context = super().get_context_data(**kwargs)
        context['now'] = timezone.now()
        return context

class PanneDetailView(DetailView):
    template_name = "panne-details.html"
    model = Panne

    context_object_name = "panne"


    def panne_detail_view(request, primary_key):
        try:
            panne = Panne.objects.get(pk=primary_key)
        except Panne.DoesNotExist:
            raise Http404('Cette panne n/existe pas')

        return render(request, 'panne-details.html', context={'panne': panne})

class PanneAjoutView(CreateView):
    template_name = 'ajoutpanne.html'
    fields = '__all__'
    model = Panne
    success_url = reverse_lazy('panne-list')
    def get_form(self):
        form = super(PanneAjoutView, self).get_form()
        form.fields['datedetection'].widget = DateTimePickerInput(format='%d/%m/%Y %H:%M')
        return form




class PanneSuppressionView(DeleteView):
    template_name = 'suppressionpanne.html'
    model = Panne
    success_url = reverse_lazy('panne-list')



    # def get_object(self):
    #         return self.queryset.get(id=self.kwargs['id'])


class PanneUpdateView(UpdateView):
    template_name = 'updatepanne.html'
    model = Panne
    fields = '__all__'
    success_url = reverse_lazy('panne-list')
