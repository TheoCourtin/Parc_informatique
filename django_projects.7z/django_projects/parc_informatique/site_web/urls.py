from django.contrib import admin
from django.urls import path, include # new
from django.views.generic.base import TemplateView # new
from django.views.generic import ListView
from site_web.views import PanneListView, PanneDetailView, PanneAjoutView, PanneSuppressionView, PanneUpdateView


#app_name="site_web"
urlpatterns = [
    #path('admin/', admin.site.urls),
	#path('accounts/', include('django.contrib.auth.urls')),
    path('', TemplateView.as_view(template_name='home.html'), name='home'),
    path('panne-list', PanneListView.as_view(template_name='panne-list.html'), name='panne-list'),
    path('panne-details/<int:pk>', PanneDetailView.as_view(template_name='panne-details.html'), name='panne-details'),
    path('ajoutpanne', PanneAjoutView.as_view(template_name='ajoutpanne.html'),name='ajoutpanne'),
    path('suppressionpanne/<int:pk>', PanneSuppressionView.as_view(template_name='suppressionpanne.html'),name='suppressionpanne'),
    path('updatepanne/<int:pk>', PanneUpdateView.as_view(template_name='updatepanne.html'),name='updatepanne'),

]
