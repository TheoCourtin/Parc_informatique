from django.contrib import admin

# Register your models here.

from .models import Panne, Machine, Salle

admin.site.register(Panne)
admin.site.register(Machine)
admin.site.register(Salle)
