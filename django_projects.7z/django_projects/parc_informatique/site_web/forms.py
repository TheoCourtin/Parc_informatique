from django import forms
from site_web.models import Panne, Type_Machine, Type_Panne, Utilisateur, Salle, Machine, Etat_Panne

# from .models import Post
#
# class PostForm(forms.ModelForm):
#
#     class Meta:
#         model = Post
#         fields = ('Compte', 'Mot de passe',)
class PanneForm(forms.Form):

   class Meta:
        model = Panne
